
# Allminder Clone - Interval Alarm App

Ye Allminder app ka clone hai jisme screenshots wale saare features + Volume Mute feature hai.

### Features Implemented:
1.  **Home Screen:** Alarm List, Next Alarm Preview, ON/OFF Toggle, Search & Sort
2.  **New Alarm Screen:**
    - Multiple Day & Time slots ( + / - )
    - Title with Emoji & Voice Input
    - Repeat?: Every X [Hours:Minutes / Days / Weekly / Month(s) / Years]
    - Play on holidays
    - Finish?: After X Days/Weeks (Auto Stop)
    - Sound and Notification
    - Smart Actions
3.  **Special Feature - Volume Mute & Keep Repeat:**
    - Volume Up/Down press karne par sirf current alarm mute hoga.
    - Repeat schedule cancel nahi hoga, agla alarm time par bajega.
    - Logic: `AlarmRingingActivity.kt` -> `onKeyDown()` me dekho.

### Tech Stack:
- Kotlin, Room DB, AlarmManager + WorkManager, Foreground Service

### Build:
Android Studio me open karo -> Sync -> Run

### Volume Mute Logic:
`app/src/main/java/com/allminder/clone/AlarmRingingActivity.kt` file me dekhna. `alarmManager.cancel()` call nahi kiya hai mute par.

Workflow folder tum alag se banaoge isliye is zip me nahi hai.
