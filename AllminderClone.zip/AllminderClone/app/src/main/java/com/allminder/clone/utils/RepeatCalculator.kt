
package com.allminder.clone.utils

import java.util.Calendar

object RepeatCalculator {
    // Screenshot me jo logic hai: every 0 hours 20 minutes / 1 Hours:Minutes / Days / Weekly / Month / Years
    fun calculateNextTrigger(currentMillis: Long, everyValue: Int, unit: String): Long {
        val cal = Calendar.getInstance().apply { timeInMillis = currentMillis }
        when(unit) {
            "Hours:Minutes", "Minutes" -> cal.add(Calendar.MINUTE, everyValue)
            "Hours" -> cal.add(Calendar.HOUR, everyValue)
            "Days" -> cal.add(Calendar.DAY_OF_YEAR, everyValue)
            "Weekly" -> cal.add(Calendar.WEEK_OF_YEAR, everyValue)
            "Month (s)", "Months" -> cal.add(Calendar.MONTH, everyValue)
            "Years" -> cal.add(Calendar.YEAR, everyValue)
        }
        return cal.timeInMillis
    }
}
