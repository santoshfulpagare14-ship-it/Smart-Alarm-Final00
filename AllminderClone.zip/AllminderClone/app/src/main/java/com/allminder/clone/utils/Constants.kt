
package com.allminder.clone.utils

object Constants {
    const val ACTION_RING = "ACTION_RING"
    const val EXTRA_ALARM_ID = "alarm_id"
    const val PREFS_FINISH_MAP = "finish_map"
}
