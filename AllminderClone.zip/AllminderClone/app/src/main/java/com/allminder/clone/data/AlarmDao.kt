
package com.allminder.clone.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AlarmDao {
    @Query("SELECT * FROM alarms ORDER BY createdAt DESC")
    fun getAllAlarms(): Flow<List<AlarmEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlarm(alarm: AlarmEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimes(times: List<AlarmTime>)

    @Query("SELECT * FROM alarm_times WHERE alarmId = :alarmId")
    suspend fun getTimesForAlarm(alarmId: Long): List<AlarmTime>

    @Query("DELETE FROM alarm_times WHERE alarmId = :alarmId")
    suspend fun deleteTimesForAlarm(alarmId: Long)

    @Query("UPDATE alarms SET isActive = :active WHERE id = :id")
    suspend fun setActive(id: Long, active: Boolean)

    @Query("DELETE FROM alarms WHERE id = :id")
    suspend fun deleteAlarm(id: Long)
    
    @Query("SELECT * FROM alarms WHERE id = :id")
    suspend fun getAlarmById(id: Long): AlarmEntity?
}
