
package com.allminder.clone

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * Is Activity me Screenshot 2 aur 3 wala UI banana hai
 * - Active Toggle
 * - Title + Emoji dropdown + Mic
 * - Day and Time: RecyclerView jisme + / - button se multiple dates add ho
 * - Repeat? Toggle + Every value + Hours:Minutes/Days/Weekly/Month/Years spinner (Screenshot 3)
 * - Play on holidays Checkbox + Settings Icon
 * - Finish? After X Days
 * - Sound and Notification expandable
 * - Smart actions toggle
 * - Top bar: Save (tick) / Delete (trash)
 */
class NewAlarmActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // setContentView(R.layout.activity_new_alarm)
        // Yahan saara form ka logic likhna hai
    }
}
