
package com.allminder.clone

import android.media.RingtoneManager
import android.os.Bundle
import android.os.Vibrator
import android.view.KeyEvent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.allminder.clone.utils.RepeatCalculator
import android.media.Ringtone

/**
 * YE TUMHARA MAANGA HUA SPECIAL FEATURE IS FILE ME HAI
 * Volume Up/Down -> Mute current instance, Repeat chalu rahega
 */
class AlarmRingingActivity : AppCompatActivity() {

    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null
    private var alarmId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // setContentView(R.layout.activity_ringing) // Tumhara layout
        alarmId = intent.getLongExtra("alarm_id", -1L)

        // Ringtone bajao
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        ringtone = RingtoneManager.getRingtone(this, uri)
        ringtone?.play()

        vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
        vibrator?.vibrate(longArrayOf(0, 1000, 1000), 0)
    }

    // ======= VOLUME MUTE LOGIC START =======
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            muteCurrentAlarmOnly()
            return true // System volume change ko rok do
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    private fun muteCurrentAlarmOnly() {
        // 1. Sirf current ringing band karo
        ringtone?.stop()
        vibrator?.cancel()

        // 2. IMPORTANT: alarmManager.cancel() YAHAN CALL MAT KARNA
        // Agar cancel karoge to repeat khatam ho jayega. Hum chahte hai agla repeat baje.

        // 3. User ko next time dikhao (RepeatCalculator se nikalo)
        // val nextTime = RepeatCalculator.calculateNextTrigger(...)
        Toast.makeText(this, "Muted! Repeat chalu hai, agla alarm bajega.", Toast.LENGTH_LONG).show()

        // 4. Is instance ko skip mark karo (Optional - history ke liye)
        // viewModel.markSkipped(alarmId)

        // 5. Activity band karo
        finish()
    }
    // ======= VOLUME MUTE LOGIC END =======

    override fun onDestroy() {
        ringtone?.stop()
        vibrator?.cancel()
        super.onDestroy()
    }
}
