
package com.allminder.clone.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.allminder.clone.AlarmRingingActivity
import com.allminder.clone.data.AppDatabase
import androidx.room.Room
import com.allminder.clone.utils.Constants
import com.allminder.clone.utils.RepeatCalculator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val alarmId = intent.getLongExtra(Constants.EXTRA_ALARM_ID, -1L)
        if(alarmId == -1L) return

        // 1. Ringing Activity kholo
        val ringingIntent = Intent(context, AlarmRingingActivity::class.java).apply {
            putExtra(Constants.EXTRA_ALARM_ID, alarmId)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        context.startActivity(ringingIntent)

        // 2. Agar repeat ON hai to agla alarm schedule karo (Mute feature ke liye important - ye yahi se hota hai)
        CoroutineScope(Dispatchers.IO).launch {
            val db = Room.databaseBuilder(context, com.allminder.clone.data.AppDatabase::class.java, "allminder.db").build()
            val alarm = db.alarmDao().getAlarmById(alarmId)
            if(alarm != null && alarm.repeatEnabled && alarm.isActive) {
                val nextTrigger = RepeatCalculator.calculateNextTrigger(System.currentTimeMillis(), alarm.repeatEveryValue, alarm.repeatUnit)
                // Yahan AlarmManager se nextTrigger set karo
                // AlarmScheduler.schedule(context, alarmId, nextTrigger) -> Tumhe ye function banana hai
            }
        }
    }
}
