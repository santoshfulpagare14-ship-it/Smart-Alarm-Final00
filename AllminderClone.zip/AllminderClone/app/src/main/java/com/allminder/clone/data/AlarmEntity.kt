
package com.allminder.clone.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "Drink water",
    val emoji: String = "⏰📌",
    val isActive: Boolean = true,
    val repeatEnabled: Boolean = true,
    val repeatEveryValue: Int = 20,
    val repeatUnit: String = "Minutes", // Hours:Minutes, Days, Weekly, Month, Years
    val playOnHolidays: Boolean = true,
    val finishEnabled: Boolean = false,
    val finishAfterValue: Int = 1,
    val finishUnit: String = "Days",
    val soundUri: String? = null,
    val smartActionsEnabled: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "alarm_times")
data class AlarmTime(
    @PrimaryKey(autoGenerate = true) val timeId: Long = 0,
    val alarmId: Long,
    val dayMillis: Long, // Mon, 09/28/2026 ka millis
    val timeInMinutes: Int, // 09:39 AM -> 579
    val nextTriggerMillis: Long = 0
)
