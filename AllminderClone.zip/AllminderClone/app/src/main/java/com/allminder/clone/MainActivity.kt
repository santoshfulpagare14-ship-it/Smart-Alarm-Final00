
package com.allminder.clone

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this)
        tv.text = "Allminder Clone Home\n\nYahan RecyclerView hoga jisme alarms list dikhenge.\nScreenshot 1 jaisa UI banao.\nAdd Alarm -> NewAlarmActivity"
        tv.textSize = 18f
        setContentView(tv)
    }
}
